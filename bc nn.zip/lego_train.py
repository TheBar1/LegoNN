from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import confusion_matrix
import itertools
from keras.layers.normalization import BatchNormalization
from keras.layers.convolutional import *
from keras.optimizers import Adam
from keras.metrics import categorical_crossentropy
import librosa
import matplotlib.pyplot as plt
from keras import backend as K
from keras.models import load_model
from keras.models import Sequential
from keras.layers import Activation
from keras.layers.core import Dense , Flatten
from keras.preprocessing.image import ImageDataGenerator
import librosa.display
import time
import numpy as np
import keras


train_path = 'train'
valid_path = 'valid'
test_path = 'test'
classes = ['1x1','2x1','2x2']
target_size = (200,200)
batch_size=10
train_batches = ImageDataGenerator().flow_from_directory(train_path, target_size=target_size,classes=classes, batch_size=batch_size)
valid_batches = ImageDataGenerator().flow_from_directory(valid_path, target_size=target_size,classes=classes, batch_size=batch_size)
test_batches = ImageDataGenerator().flow_from_directory(test_path, target_size=target_size,classes=classes, batch_size=batch_size)
model = load_model('legoNN.h5')
validation_steps = 2000 / batch_size
model.fit_generator(train_batches, steps_per_epoch=validation_steps,validation_data=valid_batches, validation_steps=validation_steps, epochs=1, verbose=2)
model.save('legoNEW.h5')
