import numpy as np
import keras
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import confusion_matrix
import itertools
import matplotlib.pyplot as plt
from keras.layers.normalization import BatchNormalization
from keras.layers.convolutional import *
from keras.optimizers import Adam
from keras.metrics import categorical_crossentropy
import librosa
import os.path
import librosa.display
from keras import backend as K
from keras.models import load_model
from keras.models import Sequential
from keras.layers import Activation
from keras.layers.core import Dense , Flatten
from keras.preprocessing.image import ImageDataGenerator


def predict(model, test_batches):
    predictions = model.predict_generator(test_batches, steps=1, verbose=0)
    print('[1x1, 2x1, 2x2]')
    print(predictions)


train_path = 'train'
valid_path = 'valid'
test_path = 'test'
classes = ['1x1','2x1','2x2']
target_size = (200,200)
batch_size=10
train_batches = ImageDataGenerator().flow_from_directory(train_path, target_size=target_size,classes=classes, batch_size=batch_size)
valid_batches = ImageDataGenerator().flow_from_directory(valid_path, target_size=target_size,classes=classes, batch_size=batch_size)
test_batches = ImageDataGenerator().flow_from_directory(test_path, target_size=target_size,classes=classes, batch_size=batch_size)
imgs, labels = next(train_batches)
train_labels = []
train_samples = []
validation_steps = 2000 / batch_size

if(os.path.isfile('legoNN.h5')):
	model = load_model('legoNN.h5')

else:

	model = Sequential()
	model.add(Conv2D(filters = 32, kernel_size = (3, 3), activation = 'relu', input_shape = (200, 200, 3)))
	model.add(Flatten())
	model.add(Dense(len(classes), activation='softmax'))
	model.compile(Adam(lr=.0001),loss='categorical_crossentropy',metrics=['accuracy']) 
	model.summary()
	model.fit_generator(train_batches, steps_per_epoch=validation_steps,validation_data=valid_batches, validation_steps=validation_steps, epochs=5, verbose=2)
	model.save('legoNN.h5')

predict(model, test_batches)



